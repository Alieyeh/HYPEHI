__version__ = '0.1.8'
__author__ = 'Jiayi Wang, Alieyeh Sarabandi Moghaddam'

from pathlib import Path
PACKAGEDIR = Path(__file__).parent.absolute()
